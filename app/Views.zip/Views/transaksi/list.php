<?= $this->extend('layout/template')  ?>

<?= $this->section('content') ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">TRANSAKSI</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Transaksi Peminjaman</li>
            
        </ol>
        
        <!-- start Flash Data -->
        <?php if (session()->getFlashdata('msg')) : ?>
            <div class="alert alert-success" role="alert">
                <?= session()->getFlashdata('msg')  ?>
            </div>
        <?php endif; ?>
        <!-- End Flash Data -->
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                <?= $title ?>
            </div>
            <div class="card-body">
                <!-- isi POS -->
                <div class="container">
                    <div class="row">
                        <div class="col mt-4">
                            <label class="col-from-label">Tanggal: </label>
                            <input type="text" value="<?= date('d/m/y') ?>" disabled>
                        </div>
                        <div class="col mt-4">
                            <label class="col-form-label">User: </label>
                            <input type="text" value="<?= user()->username ?>" disabled>
                        </div>
                        <div class="col mt-1">
                            <label class="col-form-label">Customer: </label>
                            <input type="text" id="nama-cust" disabled>
                            <input type="hidden" id="id-cust">
                        </div>
                        <div class="col">
                            <button class="btn btn-primary " data-bs-target="#modalProduk" data-bs-toggle="modal">Pilih Kendaraan </button>
                            <button class="btn btn-dark mt-3" data-bs-target="#modalSup" data-bs-toggle="modal">Cari Customer</button>
                        </div>
                    </div>
                </div>
                <table class="table table-striped table-hover mt-4">
                
                 <div class=" dataTable-search  col-md-2 "><input class="dataTable-input" placeholder="Search..." type="text"></div>
                 <a class="btn btn-success mt-3 ml-3" type="button" href="beranda.php">Kembali</a>
                    <!-- <a class="btn btn-primary mt-3 ml-3" type="button" href="/transaksi/create">Transaksi Baru</a> -->
                 
                 
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Sampul</th>
                            <th>Nama Mobil</th>
                            <th>Tahun </th>
                            <th>Harga</th>
                            <th>Jenis</th>
                            <th>Warna</th>
                            
                        </tr>
                    </thead>
                    <tbody id="detail_cart">
                    </tbody>
                </table>

                <div class="mb-3 row">
                    <label for="nama_penjamin" class="col-sm-2 col-form-label">Nama penjamin</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control ">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="alamat_penjamin" class="col-sm-2 col-form-label">Alamat penjamin </label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control ">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="no_telp_penjamin" class="col-sm-2 col-form-label">No Telepon Penjamin </label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control ">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="jenis_sewa" class="col-sm-2 col-form-label">Jenis Sewa </label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control ">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="jasa_driver" class="col-sm-2 col-form-label">Jasa Driver</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control ">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="tgl_mulai" class="col-sm-2 col-form-label">Tanggal Mulai</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control ">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="tgl_selesai" class="col-sm-2 col-form-label">Tanggal Selesai</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control ">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="tujuan" class="col-sm-2 col-form-label">Tujuan </label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control ">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="jaminan" class="col-sm-2 col-form-label">Jaminan </label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control ">
                    </div>
                </div>



                <div class="container">
                    <div class="row">
                        <div class="col-8">
                            <label class="col-form-label">Total Bayar</label>
                            <h1><span id="spanTotal">0</span></h1>
                        </div>
                        <div class="col-4">
                            <div class="mb-3 row">
                                <label class="col-4 col-form-label">Status</label>
                                <div class="col-8">
                                    <select name="status" id="status">
                                        <option value="Inrent">In rent</option>
                                        <option value="Selesai">Selesai</option>

                                    </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-4 col-form-label">Nominal</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" id="nominal" autocomplete="off">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-4 col-form-label">Kembalikan</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" id="kembalian" disabled>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-grid gap-3 d-md-flex justify-content-md-end">
                        <button onclick="bayar()" class="btn btn-success me-md-2" type="button">Proses Bayar</button>
                        
                    </div>
                </div>
                <!-- -->
            </div>
        </div>
    </div>
</main>
<?= $this->include('transaksi/modal-produk') ?>
<?= $this->include('transaksi/modal-customer') ?>
<script>
    function load() {
        $('#detail_cart').load('/transaksi/load');
        $('#spanTotal').load('/transaksi/gettotal');
    }

    $(document).ready(function() {
        load();
    });

    // Ubah Jumlah Item
    $(document).on('click', '.ubah_cart', function() {
        var row_id = $(this).attr("id");
        var qty = $(this).attr("qty");
        $('#rowid').val(row_id);
        $('#qty').val(qty);
        $('#modalUbah').modal('show');
    });

    //Hapus Item Cart
    $(document).on('click', '.hapus_cart', function() {
        var row_id = $(this).attr("id");
        $.ajax({
            url: "transaksi/" + row_id,
            method: "DELETE",
            success: function(data) {
                load();
            }
        });
    });

    // Pembayaran 
    function bayar() {
        var nominal = $('#nominal').val();
        var idsup = $('#id-sup').val();
        $.ajax({
            url: "/transaksi/bayar",
            method: "POST",
            data: {
                'nominal': nominal,
                'id-sup': idsup
            },
            success: function(response) {
                var result = JSON.parse(response);
                swal({
                    title: result.msg,
                    icon: result.status ? "success" : "error",
                })
                load();
                $('#nominal').val("");
                $('#kembalian').val(result.data.kembalian);
            }
        });
    }
</script>
<?= $this->endSection() ?>