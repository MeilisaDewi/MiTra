<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>

<div class="container-1">
                <div class="jumbotron text-left">
                    <h2>Container</h2>
                </div>

                <div class="row">
                    <div class="text-center bg-primary">
                        <h5>Container 1 - Gambar</h5>
                    </div>
                    <div class="col-sm-4 bg-success">
                        <div class="text-center">
                            <br>
                            <img style="height : 250px; width : 230px;" src="<?= base_url('assets/img/a.png'); ?>">
                            <p style="font-weight: bold;">Foto Uajy</p>
                        </div>
                    </div>
                    <div class="col-sm-4 bg-warning">
                        <div class="text-center">
                            <br>
                            <img style="height : 250px; width : 230px;" src="<?= base_url('assets/img/b.jpg'); ?>">
                            <p style="font-weight: bold;">Foto Diri</p>
                        </div>
                    </div>
                    <div class="col-sm-4 bg-danger">
                        <div class="text-center">
                            <br>
                            <img style="height : 250px; width : 230px;" src="<?= base_url('assets/img/c.jpg'); ?>">
                            <p style="font-weight: bold;">Foto Gedung Bonaventura</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-2">

                <div class="row">
                    <div class="jumbotron text-center bg-secondary">
                        <h5>Container 2 - Pesan dan Kesan Saya</h5>
                    </div>
                    <div class="col-sm-4 bg-primary">
                        <h4 class="text-center">Pengalaman Belajar SIWEB :</h4><br>
                        <p>Saya merasa senang dapat belajar SIWEB ini pada semester 4 ini dan sya merasa senang dengan proses pembelajaran matakuliah ini.</p>
                        <p>Terimakasih kepada Pak Yoh dan juga Asdos saya kak Juan karena telah membatu selama mengikuti mata kuliah ini.</p>
                        <p></p>
                        <p></p>
                        <p></p>
                    </div>
                    <div class="col-sm-8 text-center bg-info">
                        <h4>Pesan dan Kesan untuk Kak Juan  :</h4>
                        <p>Terimakasih kak Juan selama menjadi asdos saya. Kak juan sudah membantu dengan sangat baik dan pengertian ketika saya mati listrik, diberi keringanan oleh kak Juan saya sangat amat berterimakasih kak.</p>
                    </div>
                </div>

            </div>
            
</main>
<?= $this->endSection() ?>