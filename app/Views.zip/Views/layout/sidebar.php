<div id="layoutSidenav">
    
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-light" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            
                            <a class="nav-link" href="/">
                                <div class="sb-nav-link-icon text-primary"><i class="fas fa-tachometer-alt"></i></div>
                                Home 
                            </a> 

                            <?php if(has_permission('users')):?>
                              <a class="nav-link" href="/users">
                              <div class ="sb-nav-link-icon text-primary"><i class ="fas fa-users"></i></div>
                              User
                              </a>
                                             
                            </a>
                            <?php endif; ?> 
                         
                            <a class="nav-link" href="/logout">
                                <div class="sb-nav-link-icon text-primary"><i class="fas fa-coffee-alt"></i></div>
                                Log Out
                            </a> 
                            </div>

                            
                    </div>
                    <div class="sb-sidenav-footer text-primary">
                        <div class="small text-warning">Logged in as:</div>
                        Dominikus Ivan Hendyantoro /OWNER 
                    </div>
                </nav>
                
            </div>