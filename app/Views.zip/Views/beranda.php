<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4 text-primary text-center  ">Mita Transport Jogja</h1>

                        
                        <html>

<body>

<div class="container">
  
  <div class="spinner-grow text-primary"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-warning"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-success"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-primary"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-warning"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-success"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-primary"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-warning"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-success"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-primary"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-warning"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-success"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-primary"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-warning"></div>
  <div class="spinner-grow text-light"></div>
  <div class="spinner-grow text-success"></div>
  <div class="spinner-grow text-light"></div>
  
  
  

  
  
  
</div>

</body>
</html> 



  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  /* Make the image fully responsive */
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }
  </style>
<div class="d-flex gap-4">

  <div id="demo" class="carousel slide w-75 mt-4" data-ride="carousel ">
    <ul class="carousel-indicators">
      <li data-target="#demo" data-slide-to="0" class="active "></li>
      <li data-target="#demo" data-slide-to="1"></li>
      <li data-target="#demo" data-slide-to="2"></li>
    </ul>
    <div class="carousel-inner ">
      <div class="carousel-item active">
        <img src="<?= base_url('assets/img/mobil1.jpg'); ?>" alt="Los Angeles" width="1100" height="500">
        <div class="carousel-caption  ">
          <h3>New Civic</h3>
          <p>2022</p>
        </div>   
      </div>
      <div class="carousel-item">
        <img src="<?= base_url('assets/img/mobil2.jpg'); ?>" alt="Chicago" width="1100" height="500">
        <div class="carousel-caption">
          <h3>New Brio</h3>
          <p>2021</p>
        </div>   
      </div>
      <div class="carousel-item">
        <img src="<?= base_url('assets/img/mobil3.jpg'); ?>" alt="New York" width="1100" height="500">
        <div class="carousel-caption">
        <h3>New Avanza </h3>
          <p>2022</p>
        </div>   
      </div>
      
    </div>
    <a class="carousel-control-prev" href="#demo" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>
  
  <div>
  <div class="container mt-5">
    <h2>Toyota Supra 2022</h2>
    <p>Mobil mewah harga nga mewah</p>
    <div class="card" style="width:400px">
      <img class="card-img-top" src="<?= base_url('assets/img/mobil4.jpg'); ?>" alt="Card image" style="width:100%">
      <div class="card-body">
        <h4 class="card-title">Best on this year</h4>
        <p class="card-text">Memberikan anda pengalaman baru ketika menaikinya </p>
        <a href="/transaksi" class="btn btn-primary stretched-link">Cek Harga</a>
      </div>
    </div>
  </div>
  </div>
</div>

</body>
</html>

<a href="/kendaraan"><button type="button"  class="btn btn-primary btn-sm btn-block w-75 "  >Find Ur Car</button>


                    <?= $this->endSection() ?>